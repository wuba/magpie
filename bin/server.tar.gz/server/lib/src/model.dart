class Pair<F, S> {
  final F first;
  final S second;

  Pair(this.first, this.second);
}
